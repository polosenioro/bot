# config.py

# @yaeda_rabota_bot
BOT_TOKEN_COURIER = "7923388911:AAG4f00BQfppcs8Gm_cdVz2FYKDlvumDZkw"
COURIER_BOT_USERNAME = "yaeda_rabota_bot"

# @yandex_promoter_bot
BOT_TOKEN_RECRUITER = "8151432214:AAFZMo9E7M_VrYjWHHSQ_XdEGoR7J18lIJU"

VORONKA = "https://reg.eda.yandex.ru/?advertisement_campaign=forms_for_agents&user_invite_code=0d2ded991e71475aabdb658c01a9dcfe&utm_source=voronka&utm_content={ref_id}"
